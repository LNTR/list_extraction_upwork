from bs4 import BeautifulSoup

import pandas as pd
import requests
import time


FILE_NAME = "20.1842"

columns = ["Surname/Firstname" ,"postion"]

df = pd.DataFrame(columns = columns)

BASE_URL="http://qazax-ih.gov.az/az/sura.html"


session = requests.Session()

session.headers.update(
    {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/114.0",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",}
    )



def main():

    response = get_response(BASE_URL)
    if response.status_code == 200:
        html = response.content.decode("utf-8")
        add_data_to_df(html)
    else:
        print(f"Error code {response.status_code}")

    
    df.to_csv(f"./csv/{FILE_NAME}.csv",index = False,encoding = 'utf-8')


    
def add_data_to_df(html):
    
    soup = BeautifulSoup(html,"lxml")
    div_tag=soup.find(class_="metn")
    candidate_p_tag_list=filter(lambda p:("-" in p.text) or (":" in p.text),
                                div_tag.find_all("p")[1:])
    
    for p_tag in candidate_p_tag_list:
        if ":" not in str(p_tag):
            row_data=get_row_data_list(p_tag)
            df.loc[len(df)+1] = row_data


def get_row_data_list(p_tag:BeautifulSoup):
    row_value_list=[]
    p_text=p_tag.text.strip()
    
    name=p_text.split("-")[0]
    position=p_text.split("-")[1]

    row_value_list.append(name)
    row_value_list.append(position)


    return row_value_list

def get_response(url,*args,**kwargs):
    try:
        response = session.get(url,*args,**kwargs)
        return response
    except Exception as e:
        print(f"Error {e}\n Retrying in 5s")
        time.sleep(2)
        return get_response(url,*args,**kwargs)

if __name__ == "__main__":
    main()


